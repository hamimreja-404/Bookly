# WhatsApp Appointment Booking Bot — Architecture & Code Walkthrough

This document provides a comprehensive walkthrough of the **WhatsApp Booking Bot** codebase. It covers the recommended reading path, the system's architecture, database models, and a breakdown of all source files.

---

## 📖 Recommended Reading Path

To quickly grasp how this application behaves, follow this sequence:

1. **`sql/schema.sql`**: Understand the data layers — bookings and user state sessions.
2. **`src/server.js`**: See how Meta WhatsApp Webhooks arrive at the Node.js/Express server.
3. **`src/handlers/flowHandler.js`**: Understand the conversational state machine and booking steps.
4. **`src/utils/slotGenerator.js`**: See how dynamic appointment time slots are calculated (avoiding double bookings & past times).
5. **`src/services/`**: Study individual service helpers for database calls and the Meta API wrapper.

---

## 🏗️ Architecture & How It Works

The application operates as a **Stateful Webhook Handler** that communicates with the **Meta WhatsApp Cloud API** and uses **Supabase (PostgreSQL)** for persistence.

### High-Level Request Flow

```mermaid
sequenceDiagram
    autonumber
    actor User as WhatsApp User
    participant Meta as Meta Cloud API
    participant Express as Express Server (server.js)
    participant Flow as Flow Handler (flowHandler.js)
    participant DB as Supabase DB
    participant Cron as Reminder Cron (reminderCron.js)

    User->>Meta: Sends Message ("Book")
    Meta->>Express: POST Webhook Event
    Express->>Flow: handleIncoming(from, type, body)
    
    rect rgb(30, 41, 59)
        Note over Flow, DB: Stateful Transition
        Flow->>DB: Fetch user state (getSession)
        Flow->>Flow: Calculate next state / action
        Flow->>DB: Update user state (setSession)
    end

    Flow->>Meta: Send Response (Buttons/Lists/Text)
    Meta->>User: Displays message

    %% Cron Section
    loop Every 1 Minute
        Cron->>DB: Query appointments starting in next 20 mins
        DB-->>Cron: Returns list of upcoming bookings
        Cron->>Meta: Send Reminder SMS/WhatsApp text
        Cron->>DB: Update booking (reminder_sent = true)
    end
```

### Key Components

1. **Webhook Receiver**: Express server inside [server.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/server.js) acts as an endpoint matching Meta's webhook specifications.
2. **Session Engine**: Utilizes [session.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/session.js) and Supabase to persist user conversations. Since webhooks are stateless, the bot relies on the user's phone number as a unique key to determine their step in the booking funnel.
3. **Conversational State Machine**: [flowHandler.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/flowHandler.js) manages step transitions:
   `idle` ➔ `awaiting_date` ➔ `awaiting_slot` ➔ `awaiting_name` ➔ `idle` (booking saved).
4. **Slot Generator**: [slotGenerator.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/utils/slotGenerator.js) generates a master list of possible booking times, filters out past times (if booking for today), and excludes already-booked slots retrieved from the database.
5. **Background Scheduler**: [reminderCron.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/reminderCron.js) uses `node-cron` to continuously check the database and dispatch automated reminders to users 20 minutes before their scheduled appointments.

---

## 🗄️ Database Schema & State Models

Defined in [schema.sql](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/sql/schema.sql):

### 1. `bookings` Table
Stores details of finalized appointments.
* **`phone`**: WhatsApp number of the customer (serves as the identifier).
* **`booking_date`** & **`slot_time`**: The date (e.g. `2026-06-20`) and human-readable time (e.g. `10:20 AM`).
* **`slot_start`**: A full `TIMESTAMPTZ` timestamp of the appointment's beginning, used for querying upcoming reminders efficiently.
* **`status`**: Active booking status (`confirmed`, `cancelled`, or `completed`).
* **`reminder_sent`**: Tracks whether the cron job has processed the 20-minute notification.

### 2. `user_sessions` Table
Tracks progress through the conversational funnel.
* **`phone`** (Primary Key): The user's WhatsApp ID.
* **`step`**: Current state (`idle`, `awaiting_date`, `awaiting_slot`, `awaiting_name`).
* **`selected_date`**: The date chosen during Step 1.
* **`selected_slot`**: The slot chosen during Step 2.

> [!NOTE]
> Database indexes are placed on `slot_start` (to optimize cron lookups) and `(booking_date, status)` (to optimize slot availability checks).

---

## 💻 Code walkthrough & Explanations

### 1. The Entry Point: [server.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/server.js)
This file handles low-level Express configuration, webhooks routing, and starts background scripts.

* **Webhook Verification**: Meta requires a verification handshake using a GET request containing a security token. This is handled at [App Get Webhook](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/server.js#L17-L28).
* **Payload Parsing**: The POST endpoint at [App Post Webhook](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/server.js#L33-L74) parses WhatsApp webhook payloads. It checks for:
  * Message status updates (delivered, read) and ignores them to prevent loop cycles.
  * Message types: `text` (standard keyboard inputs) or `interactive` (from buttons and lists).
  * Out-of-bounds messages (sends a helper text telling users how to begin).
* **Initializers**: Starts the Express server and spins up the cron scheduling loop via [startReminderCron](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/reminderCron.js#L38-L49).

---

### 2. Conversational State Machine: [flowHandler.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/flowHandler.js)
This file governs user experience state shifts inside the core function [handleIncoming](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/flowHandler.js#L36-L94).

```
   [Idle State]
        │ (User sends "Book")
        ▼
[awaiting_date] ──► Shows interactive buttons ("Today" & "Tomorrow")
        │ (User clicks button)
        ▼
[awaiting_slot] ──► Queries slotGenerator.js, displays active slots inside a list menu
        │ (User selects a slot)
        ▼
[awaiting_name] ──► Requests user to type their full name
        │ (User types name)
        ▼
[Clear Session] ──► Saves booking inside Supabase DB, notifies user
```

* **[handleStart](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/flowHandler.js#L99-L113)**: Triggered when a user sends "book". Sets the session step to `awaiting_date` and outputs interactive buttons for Today and Tomorrow.
* **[handleDateSelected](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/flowHandler.js#L116-L142)**: Processes date selections, fetches available slots, updates step to `awaiting_slot`, and uses a WhatsApp interactive list format for display.
* **[handleSlotSelected](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/flowHandler.js#L145-L151)**: Receives the selected slot (e.g. `slot_10:00 AM`), updates session memory, and requests the user's name.
* **[handleNameReceived](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/flowHandler.js#L154-L182)**: Validates input length, triggers database write via `createBooking`, returns a confirmation, and resets session memory back to `idle`.

---

### 3. Services (Integrating External APIs & Databases)

#### 🗃️ [supabase.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/supabase.js)
* Initializes the Supabase client using environment variables.
* Disables `persistSession` (`persistSession: false`) to prevent memory leaks and configuration issues since it runs within a backend process.

#### 👤 [session.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/session.js)
* **[getSession](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/session.js#L8-L21)**: Queries `user_sessions` by phone number. If there is no active session, it falls back to a default object containing state `idle`.
* **[setSession](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/session.js#L24-L34)**: Performs an `upsert` (update-or-insert) in Supabase to sync runtime steps.
* **[clearSession](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/session.js#L37-L43)**: Reset helper returning variables back to `idle`.

#### 📅 [booking.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/booking.js)
* **[createBooking](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/booking.js#L8-L32)**: Inserts booking entries. Internally translates slot configurations to database-friendly ISO format using `buildSlotDatetime`.
* **[getUpcomingReminders](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/booking.js#L46-L64)**: Fetches confirmed appointments starting within the next 20 minutes (`slot_start` relative to current database timestamps).

#### 💬 [whatsapp.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/whatsapp.js)
Wraps calls to Meta's Cloud Graph API using `axios`.
* **`send` (Internal helper)**: Performs the actual POST request and formats token or whitelisting exceptions clearly to developers.
* **[sendText](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/whatsapp.js#L28-L35)**: Delivers standard textual messages.
* **[sendButtons](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/whatsapp.js#L39-L55)**: Renders a quick button card (WhatsApp limits this structure to 3 buttons max).
* **[sendList](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/services/whatsapp.js#L59-L79)**: Renders structured choice lists, which is perfect for rendering scheduling slots.

---

### 4. Logic & Utilities: [slotGenerator.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/utils/slotGenerator.js)
Controls appointment generation rules.

* **[buildMasterSlots](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/utils/slotGenerator.js#L4-L22)**: Generates a master list of possible booking times for the day:
  * Morning slot block: `10:00 AM` to `1:00 PM` (in 20-minute increments).
  * Lunch break: `1:00 PM` to `2:00 PM` (skipped).
  * Afternoon/evening slot block: `2:00 PM` to `7:00 PM` (last appointment starts at `6:40 PM`).
* **[getAvailableSlots](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/utils/slotGenerator.js#L41-L82)**:
  * Calculates date relativity. If the user picks *Today*, it filters out times that have already passed (allowing an extra buffer).
  * Queries database records matching the requested date.
  * Subtracts booked times from the master list to prevent double bookings.

---

### 5. Automated Reminders: [reminderCron.js](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/reminderCron.js)
Ensures appointments run on time.

* **[startReminderCron](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/reminderCron.js#L38-L49)**: Schedules a `node-cron` timer checking every minute.
* **[runReminderCheck](file:///d:/Web_desing/MOST_IMPORTANT/Whatsapp_Agent/Clude/src/handlers/reminderCron.js#L16-L36)**:
  1. Requests list of targets from the booking query service.
  2. Dispatches reminders individually.
  3. Updates status to `reminder_sent = true` in Supabase to guarantee reminders are never sent twice.
